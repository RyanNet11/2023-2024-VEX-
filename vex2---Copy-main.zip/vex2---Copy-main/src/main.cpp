#include "main.h"

/**
 * A callback function for LLEMU's center button.
 *
 * When this callback is fired, it will toggle line 2 of the LCD text between
 * "I was pressed!" and nothing.
 */
void on_center_button() {
	static bool pressed = false;
	pressed = !pressed;
	if (pressed) {
		pros::lcd::set_text(2, "I was pressed!");
	} else {
		pros::lcd::clear_line(2);
	}
}

/**
 * Runs initialization code. This occurs as soon as the program is started.
 *
 * All other competition modes are blocked by initialize; it is recommended
 * to keep execution time for this mode under a few seconds.
 */
void initialize() {
	pros::lcd::initialize();
	pros::lcd::set_text(1, "Hello PROS User!");

	pros::lcd::register_btn1_cb(on_center_button);
}

/**
 * Runs while the robot is in the disabled state of Field Management System or
 * the VEX Competition Switch, following either autonomous or opcontrol. When
 * the robot is enabled, this task will exit.
 */
void disabled() {}

/**
 * Runs after initialize(), and before autonomous when connected to the Field
 * Management System or the VEX Competition Switch. This is intended for
 * competition-specific initialization routines, such as an autonomous selector
 * on the LCD.
 *
 * This task will exit when the robot is enabled and autonomous or opcontrol
 * starts.
 */
void competition_initialize() {}

/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */
void autonomous() {}

/**
 * Runs the operator control code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the operator
 * control mode.
 *
 * If no competition control is connected, this function will run immediately
 * following initialize().
 *
 * If the robot is disabled or communications is lost, the
 * operator control task will be stopped. Re-enabling the robot will restart the
 * task, not resume it from where it left off.
 */
void driver(){	
	pros::Controller master(pros::E_CONTROLLER_MASTER);
	pros::Motor left_front(-2);
	pros::Motor left_back(-14);
	pros::Motor right_front(8);
	pros::Motor right_back(20);
	pros::Motor_Group left ({left_back, left_front});
	pros::Motor_Group right ({right_back, right_front});

	while (true) {
		pros::lcd::print(0, "%d %d %d", (pros::lcd::read_buttons() & LCD_BTN_LEFT) >> 2,
		                 (pros::lcd::read_buttons() & LCD_BTN_CENTER) >> 1,
		                 (pros::lcd::read_buttons() & LCD_BTN_RIGHT) >> 0);
		int lefts = master.get_analog(ANALOG_LEFT_Y);
		int rights = master.get_analog(ANALOG_RIGHT_Y);

		left = lefts;
		right = rights;

		pros::delay(20);
	}}
void wings(){
pros::Controller master(pros::E_CONTROLLER_MASTER);
pros::ADIDigitalOut Wings (1, LOW);
  Wings.set_value(LOW);

  while (true){

    if(master.get_digital(pros::E_CONTROLLER_DIGITAL_R2)){        //If R2 is being held


    Wings.set_value(HIGH);    //Spread the wings
      
    }else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_R1)){ //If R2 is not being held

      
      Wings.set_value (LOW); //Tuck the wings in 
  }
	pros::delay(20);
}
}
void catapult(){
 pros::Motor Catapult(9);
 pros::Motor Catapult_(-1);
 pros::Motor_Group Cata({Catapult, Catapult_});
 pros::Rotation CataPos(10);
 CataPos.set_position(0);
 pros::Controller master(pros::E_CONTROLLER_MASTER);
 bool i = false;
 //* Runs the catapult functions 
 while (true){

      if(master.get_digital(pros::E_CONTROLLER_DIGITAL_L1)){ 
        Cata.move_voltage(9000); 

        /**  Runs the normal cycle through function of the catapult while the 
       * L1 button is being pressed.. 
       * 
       * Nothing fancy about this snippet of code, when the button is 
       * held, the motor group will spin!!
      */
      
    }else if(master.get_digital(pros::E_CONTROLLER_DIGITAL_L2) && CataPos.get_angle() > 30350) {
      Cata.move_voltage(8000); 
      pros::delay(0.2); 

        /**  Runs the last ratchet placement when L2 is being pressed
       * 
       * While the L2 button is being pressed, we first check if the catapult 
       * angle is more than 30350, or 303.50 degrese. This is about where
       * the catapult's third ratchet will click into place, similar to the X 
       * button above. When the value reads false, we assume that the angle is 
       * passed where we need to set the value. While true, we sping the
       * motors at 8000 voltage. The other motors use 9000, however we found
       * that this is too fast for the values to read. Delay is also added to
       * make sure the brin can keep up with the values. The main goal of
       * the L2 setting is for match loading, as the trajectory of the third
       * ratchet when launched is almost perfect.
       */

    }else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_X)){
      i = true;
      
    }else if(master.get_digital(pros::E_CONTROLLER_DIGITAL_A)){
      i = false;
    }else if(i == true){
      if(CataPos.get_angle() > 30350) {

          //If the curent angle is greater than 30330, we spin the catapult down untill it hits 30330

          Cata.move_voltage(8000); // Spins the motors
          pros::delay(.1); //delay ensures the catapult doesnt break 

          //The goal of our L2 button program is to be able to pull back the catapult to the normal
          //launching position where the match loads can be loaded into the robot. 
      }
      else if(CataPos.get_angle() < 30360){
        pros::delay(.5);
        Cata.move_voltage(9000);
     }    }
    else
    { 
      Cata.move_voltage(0); 

        /**  STOPS all motors when values read false
       * 
       * When values above read false, such as the angle being less than 
       * a set value, or a button is no longer being pressed, we have 
       * to have a part of the function that stated what to do. We make 
       * the motor group stop at all times the values above are not true
      */

    }

    //Debugging for catapult angle

  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_Y)) {
    master.print(1, 1, "Position: %d", CataPos.get_angle());

    /** During the making of the catapult angle functions,
     * we needed a way to see the curent angle of the cata-
     * rotation sensor. To do this, we mapped the Y button
     * on the controller to print out the angle. This 
     * proved to be essential for our understanding of the 
     * rotation sensor and how it worked.
     * 
    */
   pros::delay(20);

  }
 }
}
void opcontrol() {
  pros::Task DriverControl (driver, TASK_PRIORITY_MAX,
                TASK_STACK_DEPTH_DEFAULT, "DriveTrain");
  pros::Task WingsControl (wings, TASK_PRIORITY_DEFAULT,
                TASK_STACK_DEPTH_DEFAULT, "WingExtendors");
  pros::Task cata (catapult, TASK_PRIORITY_DEFAULT,
                TASK_STACK_DEPTH_DEFAULT, "Catapult");

}



