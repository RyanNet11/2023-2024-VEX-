---
name: Bug Report Template
about: Create a bug report to help us improve the project.
title: Bug Repot Template
labels: ''
assignees: ''

---

#### Expected Behavior

#### Actual Behavior

#### Steps to Reproduce

#### Versions
Run `prosv5 conduct info-project` to see what versions you're running. 
PROS Kernel Version: 
EZ-Template Version: 

#### Additional Information

#### Failure Logs
Screenshots or snippets of code that are causing issue.
