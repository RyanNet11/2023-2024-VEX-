---
layout: default
title: Docs
nav_order: 3
has_children: true
permalink: docs
---

# Docs
Documentation for EZ-Template. 
{: .no_toc }

{: .fs-6 .fw-300 }